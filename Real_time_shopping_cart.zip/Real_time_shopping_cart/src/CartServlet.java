
import java.io.BufferedReader;
import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.google.gson.JsonParser;

@WebServlet("/CartServlet")
public class CartServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public CartServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {
			// Read the JSON data from the request
			BufferedReader reader = request.getReader();
			StringBuilder requestData = new StringBuilder();
			String line;
			while ((line = reader.readLine()) != null) {
				requestData.append(line);
			}

			// Parse the JSON data
			JsonObject jsonObject = JsonParser.parseString(requestData.toString()).getAsJsonObject();

			// Extract product data from JSON
			int productId = jsonObject.get("productId").getAsInt();
			String productName = jsonObject.get("productName").getAsString();
			String productImage = jsonObject.get("productimage").getAsString();
			String productDescription = jsonObject.get("productdescription").getAsString();
			double productPrice = jsonObject.get("productprice").getAsDouble();

			// Create a JSON object with product data
			JsonObject productObject = new JsonObject();
			productObject.addProperty("productId", productId);
			productObject.addProperty("productName", productName);
			productObject.addProperty("productimage", productImage);
			productObject.addProperty("productdescription", productDescription);
			productObject.addProperty("productprice", productPrice);

			// Access the session object
			HttpSession session = request.getSession();

			// Retrieve the cart from session storage
			JsonArray cart = (JsonArray) session.getAttribute("cart");
			if (cart == null) {
				cart = new JsonArray();
				session.setAttribute("cart", cart);
			}

			// Add the product to the cart
			cart.add(productObject);

			// Send a response back to the client with the updated cart data
			response.setContentType("application/json");
			response.getWriter().write(cart.toString());
		} catch (Exception e) {
			e.printStackTrace();
			response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			response.getWriter().write("Error adding to cart");
		}
	}

}
