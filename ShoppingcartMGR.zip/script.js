// script.js
$(document).ready(function() {
  $.getJSON('products.json', function(data) {
    displayProducts(data.products); // Pass the products array directly
  })
    .fail(function(error) {
      console.error('Error loading products.json:', error);
    });

  function displayProducts(products) {
    const productListDiv = $('#product-list');
    let html = '';
    products.forEach((product) => {
      html += `
       <div class="col-lg-4 col-md-6 col-sm-12">
      <div class="product-card">
        <h3 class="product-title">${product.title}</h3>
        <img class="product-image"  src="${product.image}" alt="${product.title}" width="200" height="180">
        <p class="product-description">${product.description}</p>
        <p class="product-price">Price: $${product.price}</p>
        <button class="add-to-cart-btn" onclick="addToCart(${product.id})">Add to Cart</button>
        </div>
        </div>
      `;
    });
    productListDiv.html(html);
  }
  // Function to filter products by category
    function filterByCategory(category) {
      if (category === 'all') {
        displayProducts(allProductsData.products);
      } else {
        const filteredProducts = allProductsData.products.filter(product => product.category === category);
        displayProducts(filteredProducts);
      }
    }
});
